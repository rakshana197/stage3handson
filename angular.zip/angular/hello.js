var num = 10;
console.log(num);
